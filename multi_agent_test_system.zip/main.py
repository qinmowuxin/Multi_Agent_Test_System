from agents.planner import PlannerAgent
from agents.coder import CodeAgent
from agents.tester import TestAgent
from agents.runner import RunnerAgent
from tools.executor import save_file

def main():
    requirement = "实现一个加法函数并进行测试"

    planner = PlannerAgent()
    coder = CodeAgent()
    tester = TestAgent()
    runner = RunnerAgent()

    plan = planner.plan(requirement)

    code = coder.generate_code()
    tests = tester.generate_tests()

    save_file("target.py", code)
    save_file("test_target.py", tests)

    result = runner.run_tests()
    print("测试结果：\n", result)

if __name__ == "__main__":
    main()
