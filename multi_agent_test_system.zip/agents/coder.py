class CodeAgent:
    def generate_code(self):
        code = '''
def add(a, b):
    return a + b
'''
        return code
