class PlannerAgent:
    def plan(self, requirement: str):
        return {
            "task": "generate_code_and_tests",
            "description": requirement
        }
