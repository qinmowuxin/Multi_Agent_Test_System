import subprocess

class RunnerAgent:
    def run_tests(self):
        result = subprocess.run(
            ["pytest", "test_target.py"],
            capture_output=True,
            text=True
        )
        return result.stdout
